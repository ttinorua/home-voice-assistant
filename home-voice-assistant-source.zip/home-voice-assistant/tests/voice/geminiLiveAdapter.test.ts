import { GeminiLiveAdapter, type LiveCallbacks, type LiveConnect } from '../../src/voice/geminiLiveAdapter';
import { pcm16ToBase64 } from '../../src/audio/pcm';
import type { CloseReason, TranscriptEvent, VoiceError } from '../../src/voice/adapter';

const cfg = { token: 'tok-1', persona: 'You are helpful', model: 'gemini-3.8-live', language: 'auto' as const };

function setup() {
  const calls: { token: string; model: string; config: any }[] = [];
  const sent: any[] = [];
  let closes = 0;
  let cbs!: LiveCallbacks;
  const connectLive: LiveConnect = async (args) => {
    calls.push({ token: args.token, model: args.model, config: args.config });
    cbs = args.callbacks;
    return { sendRealtimeInput: (p) => sent.push(p), close: () => { closes++; } };
  };
  const adapter = new GeminiLiveAdapter(connectLive);
  const closeReasons: CloseReason[] = [];
  const errors: VoiceError[] = [];
  const transcripts: TranscriptEvent[] = [];
  const audio: Int16Array[] = [];
  let interrupted = 0;
  adapter.onClose((r) => closeReasons.push(r));
  adapter.onError((e) => errors.push(e));
  adapter.onTranscript((t) => transcripts.push(t));
  adapter.onAudio((a) => audio.push(a));
  adapter.onInterrupted(() => interrupted++);
  return { adapter, calls, sent, closeReasons, errors, transcripts, audio, get cbs() { return cbs; }, get closes() { return closes; }, get interrupted() { return interrupted; } };
}

test('connect passes token, model, persona, and enables input and output transcription', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  expect(t.calls[0].token).toBe('tok-1');
  expect(t.calls[0].model).toBe('gemini-3.8-live');
  expect(t.calls[0].config.systemInstruction).toBe('You are helpful');
  expect(t.calls[0].config.responseModalities).toEqual(['AUDIO']);
  expect(t.calls[0].config.inputAudioTranscription).toBeDefined();
  expect(t.calls[0].config.outputAudioTranscription).toBeDefined();
});

test('sendAudio sends base64 audio with mime type audio/pcm;rate=16000', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  const chunk = new Int16Array([1, 2, 3]);
  t.adapter.sendAudio(chunk);
  expect(t.sent[0].audio).toEqual({ data: pcm16ToBase64(chunk), mimeType: 'audio/pcm;rate=16000' });
});

test('server audio parts become onAudio chunks', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  const b64 = pcm16ToBase64(new Int16Array([7, 8, 9]));
  t.cbs.onmessage({ serverContent: { modelTurn: { parts: [{ inlineData: { data: b64, mimeType: 'audio/pcm;rate=24000' } }] } } });
  expect(Array.from(t.audio[0])).toEqual([7, 8, 9]);
});

test('interrupted flag fires onInterrupted', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onmessage({ serverContent: { interrupted: true } });
  expect(t.interrupted).toBe(1);
});

test('input and output transcription messages become TranscriptEvents with the right role', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onmessage({ serverContent: { inputTranscription: { text: 'hej' } } });
  t.cbs.onmessage({ serverContent: { outputTranscription: { text: 'hello', finished: true } } });
  expect(t.transcripts).toEqual([
    { role: 'user', text: 'hej', final: false },
    { role: 'assistant', text: 'hello', final: true },
  ]);
});

test('an error containing RESOURCE_EXHAUSTED or status 429 becomes kind quota', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onerror?.({ message: 'got status: 429 RESOURCE_EXHAUSTED' });
  expect(t.errors[0].kind).toBe('quota');
});

test('an unexpected socket close becomes onClose dropped', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onclose?.({ code: 1006, reason: '' });
  expect(t.closeReasons).toEqual(['dropped']);
});

test('close() becomes onClose user exactly once, even when the socket close event follows', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.adapter.close();
  t.cbs.onclose?.({ code: 1000, reason: '' });
  expect(t.closeReasons).toEqual(['user']);
  expect(t.closes).toBe(1);
});

test('a goAway notice followed by a close, with no resumption handle, becomes onClose timeout', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onmessage({ goAway: { timeLeft: '10s' } });
  t.cbs.onclose?.({ code: 1000, reason: '' });
  expect(t.closeReasons).toEqual(['timeout']);
});

test('after a drop, reconnecting passes the latest session resumption handle', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onmessage({ sessionResumptionUpdate: { newHandle: 'h-42', resumable: true } });
  t.cbs.onclose?.({ code: 1006, reason: '' });
  await t.adapter.connect({ ...cfg, token: 'tok-2' });
  expect(t.calls[1].config.sessionResumption).toEqual({ handle: 'h-42' });
  expect(t.calls[1].token).toBe('tok-2');
});

test('close() during connect closes the session that finishes connecting afterwards', async () => {
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  let sessionClosed = 0;
  const connectLive: LiveConnect = async () => {
    await gate;
    return { sendRealtimeInput: () => {}, close: () => { sessionClosed++; } };
  };
  const adapter = new GeminiLiveAdapter(connectLive);
  const connecting = adapter.connect(cfg);
  adapter.close();
  release();
  await connecting;
  expect(sessionClosed).toBe(1);
});

test('a goAway notice followed by a close, when a resumption handle exists, becomes onClose dropped so the app can resume', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  t.cbs.onmessage({ sessionResumptionUpdate: { newHandle: 'h-1', resumable: true } });
  t.cbs.onmessage({ goAway: { timeLeft: '10s' } });
  t.cbs.onclose?.({ code: 1000, reason: '' });
  expect(t.closeReasons).toEqual(['dropped']);
});

test('connect enables sliding-window context compression so long sessions are not cut off', async () => {
  const t = setup();
  await t.adapter.connect(cfg);
  expect(t.calls[0].config.contextWindowCompression).toEqual({ slidingWindow: {} });
});

test('connect hints the speech languages and waits longer before deciding you finished talking', async () => {
  const t = setup();
  await t.adapter.connect({ ...cfg, language: 'da' });
  const c = t.calls[0].config;
  expect(c.inputAudioTranscription).toEqual({ languageCodes: ['da-DK'] });
  expect(c.realtimeInputConfig.automaticActivityDetection.endOfSpeechSensitivity).toBe('END_SENSITIVITY_LOW');
  expect(c.realtimeInputConfig.automaticActivityDetection.silenceDurationMs).toBeGreaterThanOrEqual(600);
});

test('connect sets the chosen voice only when one is picked', async () => {
  const a = setup();
  await a.adapter.connect({ ...cfg, voice: 'Puck' });
  expect(a.calls[0].config.speechConfig).toEqual({ voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } });
  const b = setup();
  await b.adapter.connect({ ...cfg });
  expect(b.calls[0].config.speechConfig).toBeUndefined();
});

test('connect switches the proactive-audio experiment on only when asked', async () => {
  const a = setup();
  await a.adapter.connect({ ...cfg, proactiveAudio: true });
  expect(a.calls[0].config.enableAffectiveDialog).toBeUndefined();
  expect(a.calls[0].config.proactivity).toEqual({ proactiveAudio: true });
  const b = setup();
  await b.adapter.connect({ ...cfg });
  expect(b.calls[0].config.enableAffectiveDialog).toBeUndefined();
  expect(b.calls[0].config.proactivity).toBeUndefined();
});
