import { FakeAdapter } from '../../src/voice/fakeAdapter';

const cfg = { token: 't', persona: 'p', model: 'm', language: 'auto' as const };

test('emitAudio delivers to the registered onAudio callback', () => {
  const a = new FakeAdapter();
  const got: Int16Array[] = [];
  a.onAudio((c) => got.push(c));
  a.emitAudio(new Int16Array([1, 2, 3]));
  expect(got).toHaveLength(1);
  expect(Array.from(got[0])).toEqual([1, 2, 3]);
});

test('sendAudio records chunks in sent', () => {
  const a = new FakeAdapter();
  a.sendAudio(new Int16Array([5]));
  a.sendAudio(new Int16Array([6]));
  expect(a.sent.map((c) => Array.from(c))).toEqual([[5], [6]]);
});

test('close increments closeCalls and fires onClose with user', () => {
  const a = new FakeAdapter();
  const reasons: string[] = [];
  a.onClose((r) => reasons.push(r));
  a.close();
  expect(a.closeCalls).toBe(1);
  expect(reasons).toEqual(['user']);
});

test('failNextConnect makes connect reject once, then succeed', async () => {
  const a = new FakeAdapter();
  a.failNextConnect(new Error('boom'));
  await expect(a.connect(cfg)).rejects.toThrow('boom');
  await expect(a.connect(cfg)).resolves.toBeUndefined();
  expect(a.connectCalls).toHaveLength(2);
});
