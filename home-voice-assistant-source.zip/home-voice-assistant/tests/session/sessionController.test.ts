import { FakeAdapter } from '../../src/voice/fakeAdapter';
import { PlaybackQueue, type AudioSink } from '../../src/audio/playbackQueue';
import { MESSAGES, SessionController, type MicSource, type SessionState } from '../../src/session/sessionController';
import { TokenError } from '../../src/tokenClient';

class FakeMic implements MicSource {
  running = false;
  startCalls = 0;
  denyWith: Error | null = null;
  onChunk: (c: Int16Array) => void = () => {};
  private endedCb: () => void = () => {};
  onEnded(cb: () => void) { this.endedCb = cb; }
  emitEnded() { this.endedCb(); }
  async start(onChunk: (c: Int16Array) => void) {
    this.startCalls++;
    if (this.denyWith) throw this.denyWith;
    this.running = true;
    this.onChunk = onChunk;
  }
  stop() { this.running = false; }
}

class FakeSink implements AudioSink {
  time = 1;
  scheduled: { stopped: boolean }[] = [];
  now() { return this.time; }
  schedule() { const s = { stopped: false }; this.scheduled.push(s); return { stop: () => { s.stopped = true; } }; }
}

class GatedAdapter extends FakeAdapter {
  gate: Promise<void> = Promise.resolve();
  log: string[] = [];
  async connect(c: Parameters<FakeAdapter['connect']>[0]) { await this.gate; this.log.push('connect'); return super.connect(c); }
  close() { this.log.push('close'); super.close(); }
}

class GatedMic extends FakeMic {
  gate: Promise<void> = Promise.resolve();
  async start(onChunk: (c: Int16Array) => void) { await this.gate; return super.start(onChunk); }
}

const tick = () => new Promise((r) => setTimeout(r, 0));
const chunk = (n = 2400) => new Int16Array(n);

function build(opts: { adapter?: FakeAdapter; mic?: FakeMic; getToken?: (p: string) => Promise<string> } = {}) {
  const adapter = opts.adapter ?? new FakeAdapter();
  const mic = opts.mic ?? new FakeMic();
  const sink = new FakeSink();
  const playback = new PlaybackQueue(sink, 24000);
  let clock = 0;
  const tokens: string[] = [];
  const getToken = opts.getToken ?? (async (p: string) => { tokens.push(p); return `tok-${tokens.length}`; });
  const c = new SessionController({ adapter, mic, playback, getToken, now: () => clock });
  const states: SessionState[] = [];
  const messages: { text: string; needsPasscode: boolean }[] = [];
  c.onState((s) => states.push(s));
  c.onMessage((text, needsPasscode) => messages.push({ text, needsPasscode }));
  return { c, adapter, mic, sink, playback, states, messages, tokens, setClock: (t: number) => { clock = t; } };
}

test('start goes idle → connecting → listening and streams mic chunks to sendAudio', async () => {
  const t = build();
  await t.c.start('pw');
  expect(t.states).toEqual(['connecting', 'listening']);
  t.mic.onChunk(new Int16Array([4, 5]));
  expect(Array.from(t.adapter.sent[0])).toEqual([4, 5]);
});

test('first assistant audio sets state speaking; interrupted flushes the queue and returns to listening', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitAudio(chunk());
  expect(t.c.state).toBe('speaking');
  t.adapter.emitInterrupted();
  expect(t.sink.scheduled.every((s) => s.stopped)).toBe(true);
  expect(t.c.state).toBe('listening');
});

test('stop releases the mic, closes the adapter, flushes the queue, and ends in idle', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitAudio(chunk());
  t.c.stop();
  expect(t.mic.running).toBe(false);
  expect(t.adapter.closeCalls).toBeGreaterThanOrEqual(1);
  expect(t.sink.scheduled.every((s) => s.stopped)).toBe(true);
  expect(t.c.state).toBe('idle');
});

test('stop while waiting for the token leaves no connection and no running mic', async () => {
  let release!: (v: string) => void;
  const t = build({ getToken: () => new Promise<string>((r) => { release = r; }) });
  const starting = t.c.start('pw');
  expect(t.c.state).toBe('connecting');
  await tick(); // let the token request actually begin
  t.c.stop();
  release('late-token');
  await starting;
  expect(t.adapter.connectCalls).toHaveLength(0);
  expect(t.mic.startCalls).toBe(0);
  expect(t.c.state).toBe('idle');
});

test('stop while the adapter is still connecting closes it again once connected and keeps the mic off', async () => {
  const adapter = new GatedAdapter();
  let release!: () => void;
  adapter.gate = new Promise<void>((r) => { release = r; });
  const t = build({ adapter });
  const starting = t.c.start('pw');
  await tick();
  t.c.stop();
  release();
  await starting;
  expect(t.mic.running).toBe(false);
  expect(t.mic.startCalls).toBe(0);
  expect(adapter.closeCalls).toBeGreaterThanOrEqual(2);
  expect(t.c.state).toBe('idle');
});

test('calling start twice connects once and starts one mic', async () => {
  const t = build();
  const a = t.c.start('pw');
  const b = t.c.start('pw');
  await Promise.all([a, b]);
  expect(t.adapter.connectCalls).toHaveLength(1);
  expect(t.mic.startCalls).toBe(1);
});

test('audio emitted after stop is not enqueued', async () => {
  const t = build();
  await t.c.start('pw');
  t.c.stop();
  const before = t.sink.scheduled.length;
  t.adapter.emitAudio(chunk());
  expect(t.sink.scheduled.length).toBe(before);
});

test('token 401 gives state error and asks for the passcode again', async () => {
  const t = build({ getToken: async () => { throw new TokenError(401, 'nope'); } });
  await t.c.start('bad');
  expect(t.c.state).toBe('error');
  expect(t.messages.at(-1)?.needsPasscode).toBe(true);
  expect(t.mic.startCalls).toBe(0);
});

test('mic NotAllowedError gives the mic-denied message, does not retry, and closes the adapter', async () => {
  const t = build();
  const denied = new Error('denied');
  denied.name = 'NotAllowedError';
  t.mic.denyWith = denied;
  await t.c.start('pw');
  expect(t.c.state).toBe('error');
  expect(t.messages.at(-1)?.text).toBe(MESSAGES.micDenied);
  expect(t.mic.startCalls).toBe(1);
  expect(t.adapter.closeCalls).toBeGreaterThanOrEqual(1);
});

test('dropped close triggers exactly one reconnect with a fresh token; a second drop gives state error and releases the mic', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitClose('dropped');
  await tick();
  expect(t.adapter.connectCalls).toHaveLength(2);
  expect(t.tokens).toHaveLength(2);
  expect(t.c.state).toBe('listening');
  t.adapter.emitClose('dropped');
  await tick();
  expect(t.adapter.connectCalls).toHaveLength(2);
  expect(t.c.state).toBe('error');
  expect(t.mic.running).toBe(false);
});

test('quota error shows "limit reached, try later" and releases the mic', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitError({ kind: 'quota', message: 'RESOURCE_EXHAUSTED' });
  expect(t.c.state).toBe('error');
  expect(t.messages.at(-1)?.text).toBe('limit reached, try later');
  expect(t.mic.running).toBe(false);
});

test('timeout close ends with "session ended, tap to continue" and releases the mic', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitClose('timeout');
  expect(t.c.state).toBe('ended');
  expect(t.messages.at(-1)?.text).toBe('session ended, tap to continue');
  expect(t.mic.running).toBe(false);
});

test('responseDelaysMs measures from the last loud mic chunk (end of speech) to the first reply audio', async () => {
  const t = build();
  await t.c.start('pw');
  t.setClock(1000);
  t.mic.onChunk(new Int16Array(1600).fill(3000)); // you are speaking
  t.setClock(1200);
  t.mic.onChunk(new Int16Array(1600).fill(5)); // silence
  t.setClock(1400);
  t.adapter.emitAudio(chunk());
  expect(t.c.responseDelaysMs).toEqual([400]);
});

test('quiet mic chunks never count as speech, so no delay is recorded', async () => {
  const t = build();
  await t.c.start('pw');
  t.setClock(1000);
  t.mic.onChunk(new Int16Array(1600).fill(5));
  t.setClock(1400);
  t.adapter.emitAudio(chunk());
  expect(t.c.responseDelaysMs).toEqual([]);
});

test('one speech turn gives one delay entry, even if the reply arrives in many chunks', async () => {
  const t = build();
  await t.c.start('pw');
  t.setClock(1000);
  t.mic.onChunk(new Int16Array(1600).fill(3000));
  t.setClock(1500);
  t.adapter.emitAudio(chunk());
  t.adapter.emitAudio(chunk());
  t.adapter.emitAudio(chunk());
  expect(t.c.responseDelaysMs).toEqual([500]);
});

test('speaking returns to listening when playback finishes, and the timer stops with the session', async () => {
  vi.useFakeTimers();
  try {
    const t = build();
    await t.c.start('pw');
    t.adapter.emitAudio(chunk()); // 0.1 s of audio
    expect(t.c.state).toBe('speaking');
    t.sink.time = 1.5;
    vi.advanceTimersByTime(200);
    expect(t.c.state).toBe('listening');
    t.c.stop();
    expect(vi.getTimerCount()).toBe(0);
  } finally {
    vi.useRealTimers();
  }
});

test('the user-facing strings match the spec', () => {
  expect(MESSAGES.limit).toBe('limit reached, try later');
  expect(MESSAGES.sessionEnded).toBe('session ended, tap to continue');
  expect(MESSAGES.headphones).toBe('use headphones if it talks to itself');
});

test('Start, Stop, then Start again while the first attempt is still connecting ends with one live session and the mic running', async () => {
  const adapter = new GatedAdapter();
  let release!: () => void;
  adapter.gate = new Promise<void>((r) => { release = r; });
  const t = build({ adapter });
  const first = t.c.start('pw');
  await tick();
  t.c.stop();
  const second = t.c.start('pw');
  await tick();
  release();
  await Promise.all([first, second]);
  expect(t.c.state).toBe('listening');
  expect(t.mic.running).toBe(true);
  expect(adapter.log.at(-1)).toBe('connect'); // nothing closed the newest session
});

test('a socket close while the mic is still starting is not lost: the app reconnects instead of sitting on a dead Listening screen', async () => {
  const mic = new GatedMic();
  let release!: () => void;
  mic.gate = new Promise<void>((r) => { release = r; });
  const t = build({ mic });
  const starting = t.c.start('pw');
  await tick();
  t.adapter.emitClose('dropped');
  release();
  await starting;
  await tick();
  expect(t.adapter.connectCalls).toHaveLength(2);
  expect(t.c.state).toBe('listening');
});

test('a timeout close while the mic is still starting ends the session with the session-ended message', async () => {
  const mic = new GatedMic();
  let release!: () => void;
  mic.gate = new Promise<void>((r) => { release = r; });
  const t = build({ mic });
  const starting = t.c.start('pw');
  await tick();
  t.adapter.emitClose('timeout');
  release();
  await starting;
  expect(t.c.state).toBe('ended');
  expect(t.messages.at(-1)?.text).toBe(MESSAGES.sessionEnded);
  expect(t.mic.running).toBe(false);
});

test('after a reconnect has stayed up for 30 seconds, a later drop is allowed one more reconnect (long chats keep going)', async () => {
  const t = build();
  await t.c.start('pw');
  t.adapter.emitClose('dropped');
  await tick();
  expect(t.adapter.connectCalls).toHaveLength(2);
  t.setClock(31_000);
  t.adapter.emitClose('dropped');
  await tick();
  expect(t.adapter.connectCalls).toHaveLength(3);
  expect(t.c.state).toBe('listening');
});

test('a reconnect retries when the network is still down, and succeeds once it is back', async () => {
  vi.useFakeTimers();
  try {
    let calls = 0;
    const t = build({ getToken: async () => { calls++; if (calls === 2 || calls === 3) throw new TokenError(0, 'offline'); return `tok-${calls}`; } });
    await t.c.start('pw');
    t.adapter.emitClose('dropped');
    await vi.advanceTimersByTimeAsync(10_000);
    expect(calls).toBe(4);
    expect(t.c.state).toBe('listening');
    expect(t.adapter.connectCalls).toHaveLength(2);
  } finally {
    vi.useRealTimers();
  }
});

test('a reconnect gives up with an error after three failed tries and releases the mic', async () => {
  vi.useFakeTimers();
  try {
    let calls = 0;
    const t = build({ getToken: async () => { calls++; if (calls >= 2) throw new TokenError(0, 'offline'); return 'tok'; } });
    await t.c.start('pw');
    t.adapter.emitClose('dropped');
    await vi.advanceTimersByTimeAsync(20_000);
    expect(t.c.state).toBe('error');
    expect(t.mic.running).toBe(false);
    expect(calls).toBe(4);
  } finally {
    vi.useRealTimers();
  }
});

test('when the microphone ends on its own, the session stops with a message that mentions the headphones', async () => {
  const t = build();
  await t.c.start('pw');
  t.mic.emitEnded();
  expect(t.c.state).toBe('error');
  expect(t.messages.at(-1)?.text).toBe(MESSAGES.micLost);
  expect(t.mic.running).toBe(false);
});

test('micLevel rises with loud mic chunks and is near zero for quiet ones', async () => {
  const t = build();
  await t.c.start('pw');
  t.mic.onChunk(new Int16Array(1600).fill(8000));
  const loud = t.c.micLevel;
  t.mic.onChunk(new Int16Array(1600).fill(3));
  expect(loud).toBeGreaterThan(0.1);
  expect(t.c.micLevel).toBeLessThan(0.01);
});

test('the event log records connect, drop, reconnect and stop with times', async () => {
  const t = build();
  t.setClock(1000);
  await t.c.start('pw');
  t.setClock(2000);
  t.adapter.emitClose('dropped');
  await tick();
  t.setClock(3000);
  t.c.stop();
  const texts = t.c.events.map((e) => e.text);
  expect(texts).toEqual(expect.arrayContaining(['connected', 'connection dropped, reconnecting', 'reconnected', 'stopped']));
  expect(t.c.events.find((e) => e.text === 'stopped')?.atMs).toBe(3000);
});

test('the event log keeps only the most recent 30 entries', async () => {
  const t = build();
  await t.c.start('pw');
  for (let i = 0; i < 40; i++) { t.c.stop(); await t.c.start('pw'); }
  expect(t.c.events.length).toBeLessThanOrEqual(30);
});

test('the chosen language is sent to the adapter with a matching persona, and read again on each connect', async () => {
  let lang: 'auto' | 'en' | 'da' = 'da';
  const adapter = new FakeAdapter();
  const mic = new FakeMic();
  const c = new SessionController({
    adapter, mic, playback: new PlaybackQueue(new FakeSink(), 24000),
    getToken: async () => 'tok', now: () => 0, getLanguage: () => lang,
  });
  await c.start('pw');
  expect(adapter.connectCalls[0].language).toBe('da');
  expect(adapter.connectCalls[0].persona.toLowerCase()).toMatch(/only in danish/);
  c.stop();
  lang = 'en';
  await c.start('pw');
  expect(adapter.connectCalls[1].language).toBe('en');
});

test('voice and experiment choices are sent to the adapter', async () => {
  const adapter = new FakeAdapter();
  const c = new SessionController({
    adapter, mic: new FakeMic(), playback: new PlaybackQueue(new FakeSink(), 24000),
    getToken: async () => 'tok', now: () => 0,
    getOptions: () => ({ voice: 'Kore', proactiveAudio: true }),
  });
  await c.start('pw');
  expect(adapter.connectCalls[0]).toMatchObject({ voice: 'Kore', proactiveAudio: true });
});
