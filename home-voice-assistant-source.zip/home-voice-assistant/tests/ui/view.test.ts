// @vitest-environment jsdom
import { appendTranscript, renderView, summarizeDelays, type ViewModel } from '../../src/ui/view';
import { MESSAGES } from '../../src/session/sessionController';

const base: ViewModel = { state: 'idle', transcript: [], showPasscode: false };
const handlers = () => ({ toggled: 0, passcodes: [] as string[], onToggle() { this.toggled++; }, onPasscode(v: string) { this.passcodes.push(v); } });

function mount(model: ViewModel, h = handlers()) {
  const root = document.createElement('div');
  renderView(root, model, h);
  return { root, h };
}

test('renderView shows "Start" when idle and "Stop" when listening or speaking', () => {
  expect(mount(base).root.querySelector('button')!.textContent).toBe('Start');
  expect(mount({ ...base, state: 'listening' }).root.querySelector('button')!.textContent).toBe('Stop');
  expect(mount({ ...base, state: 'speaking' }).root.querySelector('button')!.textContent).toBe('Stop');
});

test('renderView shows the status text for each state', () => {
  const expected: Record<string, string> = {
    idle: 'Ready', connecting: 'Connecting…', listening: 'Listening', speaking: 'Speaking', error: 'Something went wrong', ended: 'Session ended',
  };
  for (const [state, text] of Object.entries(expected)) {
    const { root } = mount({ ...base, state: state as ViewModel['state'] });
    expect(root.querySelector('#status')!.textContent).toBe(text);
  }
});

test('renderView shows the passcode field only when showPasscode is true', () => {
  expect(mount(base).root.querySelector<HTMLInputElement>('#passcode')!.hidden).toBe(true);
  expect(mount({ ...base, showPasscode: true }).root.querySelector<HTMLInputElement>('#passcode')!.hidden).toBe(false);
});

test('renderView shows the message text and the headphones hint in the error state', () => {
  const { root } = mount({ ...base, state: 'error', message: 'Could not connect.' });
  expect(root.querySelector('#message')!.textContent).toContain('Could not connect.');
  expect(root.querySelector('#hint')!.textContent).toBe(MESSAGES.headphones);
});

test('transcript entries render in order with the role as a label', () => {
  const { root } = mount({ ...base, transcript: [{ role: 'user', text: 'hej' }, { role: 'assistant', text: 'hello' }] });
  const items = Array.from(root.querySelectorAll('#transcript li')).map((li) => li.textContent);
  expect(items).toEqual(['You: hej', 'Assistant: hello']);
});

test('tapping the button calls onToggle, and typing a passcode calls onPasscode', () => {
  const { root, h } = mount({ ...base, showPasscode: true });
  root.querySelector('button')!.click();
  const input = root.querySelector<HTMLInputElement>('#passcode')!;
  input.value = 'abc';
  input.dispatchEvent(new Event('input'));
  expect(h.toggled).toBe(1);
  expect(h.passcodes).toEqual(['abc']);
});

test('re-rendering keeps the same passcode input element so typing is not interrupted', () => {
  const root = document.createElement('div');
  const h = handlers();
  renderView(root, { ...base, showPasscode: true }, h);
  const first = root.querySelector('#passcode');
  renderView(root, { ...base, state: 'connecting', showPasscode: true }, h);
  expect(root.querySelector('#passcode')).toBe(first);
});

test('appendTranscript joins consecutive fragments of the same role and starts a new line when the role changes', () => {
  let list = appendTranscript([], { role: 'user', text: 'Hello ', final: false });
  list = appendTranscript(list, { role: 'user', text: 'there', final: false });
  list = appendTranscript(list, { role: 'assistant', text: 'Hi!', final: false });
  expect(list).toEqual([{ role: 'user', text: 'Hello there' }, { role: 'assistant', text: 'Hi!' }]);
});

test('the headphones hint is visible while listening and speaking, not only after an error', () => {
  expect(mount({ ...base, state: 'listening' }).root.querySelector('#hint')!.textContent).toBe(MESSAGES.headphones);
  expect(mount({ ...base, state: 'speaking' }).root.querySelector('#hint')!.textContent).toBe(MESSAGES.headphones);
  expect(mount(base).root.querySelector('#hint')!.textContent).toBe('');
});

test('summarizeDelays reports last and median reply delay in seconds with the turn count', () => {
  expect(summarizeDelays([])).toBe('');
  expect(summarizeDelays([400, 1200, 800])).toBe('Reply delay: last 0.8 s, median 0.8 s over 3 turns');
  expect(summarizeDelays([1500])).toBe('Reply delay: last 1.5 s, median 1.5 s over 1 turn');
  expect(summarizeDelays([1000, 2000])).toBe('Reply delay: last 2.0 s, median 1.5 s over 2 turns');
});

test('renderView shows the stats line when given one', () => {
  expect(mount({ ...base, stats: 'Reply delay: last 0.8 s, median 0.8 s over 3 turns' }).root.querySelector('#stats')!.textContent)
    .toBe('Reply delay: last 0.8 s, median 0.8 s over 3 turns');
});

test('renderView shows a mic level meter and the most recent events in a details list', () => {
  const { root } = mount({
    ...base,
    state: 'listening',
    events: [{ atMs: Date.UTC(2026, 9, 24, 17, 32, 10), text: 'connected' }, { atMs: Date.UTC(2026, 9, 24, 17, 33, 0), text: 'connection dropped, reconnecting' }],
  });
  expect(root.querySelector('#level')).not.toBeNull();
  const lines = Array.from(root.querySelectorAll('#log li')).map((li) => li.textContent);
  expect(lines).toHaveLength(2);
  expect(lines[1]).toContain('connection dropped, reconnecting');
});

test('renderView has a language choice (Auto, English, Danish) that reports changes', () => {
  const h = { ...handlers(), languages: [] as string[], onLanguage(v: string) { this.languages.push(v); } };
  const root = document.createElement('div');
  renderView(root, { ...base, language: 'en' }, h);
  const sel = root.querySelector<HTMLSelectElement>('#language')!;
  expect([...sel.options].map((o) => o.value)).toEqual(['auto', 'en', 'da']);
  expect(sel.value).toBe('en');
  sel.value = 'da';
  sel.dispatchEvent(new Event('change'));
  expect(h.languages).toEqual(['da']);
});

test('renderView has a voice picker with female and male voices and one experiment switch that report changes', () => {
  const calls: any[] = [];
  const h = { ...handlers(), onVoice: (v: string) => calls.push(['voice', v]), onExperiment: (k: string, on: boolean) => calls.push([k, on]) };
  const root = document.createElement('div');
  renderView(root, { ...base, voice: 'Puck' }, h);
  const sel = root.querySelector<HTMLSelectElement>('#voice')!;
  expect(sel.value).toBe('Puck');
  expect([...sel.options].length).toBe(9); // default + 8
  sel.value = 'Kore'; sel.dispatchEvent(new Event('change'));
  expect(root.querySelector('#affective')).toBeNull();
  const pro = root.querySelector<HTMLInputElement>('#proactive')!;
  expect(pro.checked).toBe(false);
  pro.checked = true; pro.dispatchEvent(new Event('change'));
  expect(calls).toEqual([['voice', 'Kore'], ['proactive', true]]);
});
