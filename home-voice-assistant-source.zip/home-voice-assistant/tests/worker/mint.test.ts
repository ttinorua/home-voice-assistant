import { createGeminiMint, type Env } from '../../worker/src/index';

const env: Env = { GEMINI_API_KEY: 'SECRET-KEY-123', PASSCODE: 'pw', ALLOWED_ORIGIN: 'https://voice.example.com' };
const NOW = Date.parse('2026-10-24T12:00:00.000Z');

test('mint calls Google with the key in a header and a one-use, short-lived body, and returns the token name', async () => {
  let seen: { url: string; init: RequestInit } | undefined;
  const fetchImpl = (async (url: string, init: RequestInit) => {
    seen = { url, init };
    return new Response(JSON.stringify({ name: 'auth_tokens/xyz' }), { status: 200 });
  }) as unknown as typeof fetch;
  const token = await createGeminiMint(env, fetchImpl, () => NOW)();
  expect(token).toBe('auth_tokens/xyz');
  expect(seen!.url).toBe('https://generativelanguage.googleapis.com/v1alpha/auth_tokens');
  expect(seen!.init.method).toBe('POST');
  expect((seen!.init.headers as Record<string, string>)['x-goog-api-key']).toBe('SECRET-KEY-123');
  expect(JSON.parse(seen!.init.body as string)).toEqual({
    uses: 1,
    expireTime: '2026-10-24T12:30:00.000Z',
    newSessionExpireTime: '2026-10-24T12:01:00.000Z',
  });
});

test('mint fails without leaking the key when Google refuses the request', async () => {
  const fetchImpl = (async () => new Response(JSON.stringify({ error: { message: 'API key not valid' } }), { status: 403 })) as unknown as typeof fetch;
  const err = await createGeminiMint(env, fetchImpl, () => NOW)().catch((e) => e);
  expect(err).toBeInstanceOf(Error);
  expect(String(err.message)).not.toContain('SECRET-KEY-123');
  expect(String(err.message)).toContain('403');
});

test('mint fails when Google answers without a token name', async () => {
  const fetchImpl = (async () => new Response(JSON.stringify({}), { status: 200 })) as unknown as typeof fetch;
  await expect(createGeminiMint(env, fetchImpl, () => NOW)()).rejects.toThrow();
});
