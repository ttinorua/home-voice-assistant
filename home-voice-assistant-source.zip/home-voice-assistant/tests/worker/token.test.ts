import { handleRequest, resetRateLimits, type Env, type TokenDeps } from '../../worker/src/index';

const ORIGIN = 'https://voice.example.com';
const env: Env = { GEMINI_API_KEY: 'SECRET-KEY-123', PASSCODE: 'open-sesame', ALLOWED_ORIGIN: ORIGIN };

let minted = 0;
let clock = 0;
const deps: TokenDeps = {
  mint: async () => { minted++; return 'short-lived-token'; },
  now: () => clock,
};

function post(body: unknown, headers: Record<string, string> = {}, raw?: string) {
  return new Request('https://worker.example.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: ORIGIN, 'cf-connecting-ip': '1.1.1.1', ...headers },
    body: raw ?? JSON.stringify(body),
  });
}

beforeEach(() => { minted = 0; clock = 0; resetRateLimits(); });

test('valid passcode returns 200 and the minted token', async () => {
  const res = await handleRequest(post({ passcode: 'open-sesame' }), env, deps);
  expect(res.status).toBe(200);
  expect(await res.json()).toEqual({ token: 'short-lived-token' });
  expect(res.headers.get('access-control-allow-origin')).toBe(ORIGIN);
});

test('wrong passcode returns 401 and does not call mint', async () => {
  const res = await handleRequest(post({ passcode: 'nope' }), env, deps);
  expect(res.status).toBe(401);
  expect(minted).toBe(0);
});

test('empty body, missing field, and 10 KB passcode all return 401 or 400, never 500', async () => {
  const cases = [post(null, {}, ''), post({}), post({ passcode: 'x'.repeat(10240) }), post({ passcode: 42 })];
  for (const req of cases) {
    const res = await handleRequest(req, env, deps);
    expect([400, 401]).toContain(res.status);
  }
  expect(minted).toBe(0);
});

test('passcode "æøå" wrong returns 401 without throwing', async () => {
  const res = await handleRequest(post({ passcode: 'æøå' }), env, deps);
  expect(res.status).toBe(401);
});

test('response body never contains GEMINI_API_KEY', async () => {
  const ok = await handleRequest(post({ passcode: 'open-sesame' }), env, deps);
  const bad = await handleRequest(post({ passcode: 'nope' }), env, deps);
  expect(await ok.text()).not.toContain('SECRET-KEY-123');
  expect(await bad.text()).not.toContain('SECRET-KEY-123');
});

test('11th request in a minute from one IP returns 429', async () => {
  for (let i = 0; i < 10; i++) {
    const res = await handleRequest(post({ passcode: 'nope' }), env, deps);
    expect(res.status).toBe(401);
  }
  const res = await handleRequest(post({ passcode: 'open-sesame' }), env, deps);
  expect(res.status).toBe(429);
  expect(minted).toBe(0);
});

test('foreign Origin returns 403', async () => {
  const res = await handleRequest(post({ passcode: 'open-sesame' }, { origin: 'https://evil.example.com' }), env, deps);
  expect(res.status).toBe(403);
  expect(minted).toBe(0);
});

test('GET /token returns 405', async () => {
  const res = await handleRequest(new Request('https://worker.example.com/token', { method: 'GET' }), env, deps);
  expect(res.status).toBe(405);
});

test('browser preflight (OPTIONS) from the allowed origin succeeds with CORS headers', async () => {
  const req = new Request('https://worker.example.com/token', { method: 'OPTIONS', headers: { origin: ORIGIN } });
  const res = await handleRequest(req, env, deps);
  expect(res.status).toBe(204);
  expect(res.headers.get('access-control-allow-origin')).toBe(ORIGIN);
  expect(res.headers.get('access-control-allow-methods')).toContain('POST');
});
