# Putting Home Voice online (Stage 1)

This takes about 20 minutes and is easiest on a computer. You need two free accounts: **Google AI Studio** (the voice brain) and **Cloudflare** (hosts the app). Nothing here costs money.

## What you are setting up

- The **app**: the page you open on your phone.
- The **token helper**: a tiny online service that holds your Google key safely and gives the app a temporary pass. Your key never goes on the phone.

## Step 1: Get a Google key (free)

1. Go to https://aistudio.google.com and sign in with your Google account.
2. Choose "Get API key" and create a key. Copy it somewhere private. Treat it like a password.
3. Look at the "rate limits" page in AI Studio and write down the free daily limits. We record them in the evaluation sheet.

## Step 2: Create a Cloudflare account (free)

Go to https://dash.cloudflare.com/sign-up and sign up. No payment details are needed for the free plan.

## Step 3: Publish the token helper

On a computer with Node.js installed, open a terminal in this project folder and run these one at a time:

```
npm install
npx wrangler login
cd worker
npx wrangler secret put GEMINI_API_KEY      # paste your Google key when asked
npx wrangler secret put PASSCODE            # choose a passcode, e.g. a few random words
npx wrangler deploy
```

Tip: use only plain letters and numbers (a-z, 0-9) in the passcode. Special letters like æ, ø, å can be typed differently on a phone and a computer and then fail to match.

`wrangler deploy` prints an address like `https://home-voice-assistant-token.YOURNAME.workers.dev`. Copy it. This is your **token address**.

## Step 4: Publish the app

Still in the project folder (not inside `worker`), run, replacing the address with yours:

```
VITE_TOKEN_URL="https://home-voice-assistant-token.YOURNAME.workers.dev/token" npm run build
npx wrangler pages deploy dist --project-name home-voice
```

It prints the app address, for example `https://home-voice.pages.dev`. Copy it.

## Step 5: Tell the token helper which app is allowed

Open `worker/wrangler.toml`, replace `https://REPLACE-WITH-YOUR-APP-ADDRESS` with the app address from step 4 (no slash at the end), then run:

```
cd worker
npx wrangler deploy
```

## Step 6: Try it on your phone

1. Open the app address in Chrome on your Android phone.
2. Type your passcode and tap Start. Allow the microphone when asked.
3. Say something in English, then something in Danish.
4. Optional: in Chrome's menu choose "Add to Home screen" to install it like an app.

Tip: if it talks to itself, use headphones.

## If something goes wrong

- "That passcode did not work": retype the passcode from step 3.
- "Could not connect": check the app address in step 5 matches exactly, and that the token address in step 4 ends with `/token`.
- "limit reached, try later": you used up the free quota. Try again later.
- Anything else: send me a screenshot and I will help.
