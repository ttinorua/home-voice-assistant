# Home Voice Assistant — Stage 1 Design (Voice Chat Only)

Date: 2026-10-24
Status: Draft for review

## 1. Purpose and scope

A household voice assistant you can talk to naturally. This spec covers **Stage 1 only: a phone web app for hands-free voice chat**, built on free tiers, used to test the voice loop, Danish/English quality, and latency.

**Long-term direction (not built now):** wake word, tools (calendar, weather, web search, household notes), an Android wrapper, and a dedicated home device with microphone and speaker.

**Out of scope for Stage 1:** wake word, calendar, weather, web search, memory/notes, Android wrapper, home device, user accounts, multi-user profiles.

## 2. Success criteria

1. Tap start, speak, and hear a spoken reply that feels conversational.
2. The assistant stops talking when interrupted.
3. English, Danish, and mixed-language speech work; it replies in the language used.
4. Runs at zero cost on free tiers.
5. Provider can be swapped by adding an adapter, without changing the app UI or token endpoint.

## 2a. Stage objectives and measures

Each stage has one purpose and measurable targets. A stage is "done" only when its targets are met, and the next stage does not start before that. The numbers are proposed starting targets; adjust them before the stage begins.

### Stage 1 — Voice chat (this spec)

**Purpose:** prove that natural, bilingual voice conversation works on a free tier, and decide whether Gemini Live is good enough to build on.

| Measure | Target |
|---|---|
| Response delay (end of your speech to first reply audio) | Median at most 1.5 s over 20 turns |
| Interruption | Assistant stops within 0.5 s in at least 9 of 10 trials |
| Danish | At least 8 of 10 Danish test sentences understood correctly and answered in Danish |
| Mixed language | At least 8 of 10 mixed English/Danish turns answered in the language used |
| Stability | A 10-minute conversation without a manual restart; reconnect works in at least 4 of 5 forced drops |
| Self-echo on phone speaker | No self-triggering in 5 runs, or documented as headphones-only |
| Cost | 0 (free tier only) |
| Your verdict | You rate it at least 4 out of 5 on "I would use this daily" |

**Decision at the end:** keep Gemini, add the OpenAI adapter, or switch approach.

### Stage 2 — Tools (calendar, weather, web search, household notes)

**Purpose:** make the assistant useful for planning your day, not just chatting.

| Measure | Target |
|---|---|
| Tool success | At least 90 percent of 30 scripted requests answered correctly |
| Added delay for a tool answer | At most 2 s over a plain answer |
| Weather accuracy | Matches the forecast source for Solrød on every test |
| Calendar safety | Zero calendar changes made without a spoken confirmation |

### Stage 3 — Wake word and Android wrapper

**Purpose:** hands-free use without tapping.

| Measure | Target |
|---|---|
| Wake word detection | At least 18 of 20 spoken wake phrases detected |
| False wakes | At most 1 per hour of ambient TV and talk |
| Privacy | A network log shows no audio leaves the device before the wake word |

### Stage 4 — Home device

**Purpose:** a shared household assistant that runs unattended.

| Measure | Target |
|---|---|
| Uptime | At least 99 percent over 7 days |
| Household use | At least 2 household members complete the same task set successfully |
| Monthly cost | Within a budget you set before the stage (paid tier, hard cap) |
| Privacy | Hardware mute switch works; paid tier with training use off |

## 3. Decisions and constraints

- **Language:** English and Danish from the start. Danish support in the chosen Live model is **unconfirmed** and is the first thing to test.
- **Interaction:** tap to start, then hands-free; interruptible. Wake word deferred to the home-device stage.
- **First platform:** installable web app (PWA) on the phone. Android wrapper possible later.
- **Primary provider:** Gemini Live (Google) on the free tier. Audio-to-audio, free input/output per Google's pricing page as of 2026-10-24.
- **Later provider:** OpenAI (API key, prepaid). A ChatGPT Plus/Pro subscription does not include API access and is not used.
- **Claude** has no live speech-to-speech API; it could act as a text "brain" in a pipeline in a later stage, not in Stage 1.
- **Privacy caveat:** Google marks free-tier usage as used to improve its products. Free tier is for testing with casual chat only; switch to a paid key before real household use. Switching must be a configuration change.
- **Rate limits:** free-tier numeric limits were not published on the pages checked. Verify in the user's AI Studio account before relying on them.
- **Echo:** speaker-to-mic feedback is the main phone risk. Use echo cancellation constraints; headphones are acceptable for the first test.

## 4. Architecture

Three parts: **web client**, **token endpoint**, **voice provider**.

```
Phone browser (PWA)  --(passcode)-->  Token endpoint (free serverless host)
        |                                     |
        |<------ short-lived session token ---|
        |
        +--------- live audio session (WebSocket) --------> Gemini Live
```

The Google API key lives only in the token endpoint as a secret. The browser never sees it.

### 4.1 Web client

- **Mic capture:** `getUserMedia` with echo cancellation, noise suppression, and auto gain enabled; audio processed in an AudioWorklet and converted to the PCM format the provider requires.
- **Playback:** reply audio chunks queued and played through the Web Audio API. On an interruption signal, the queue is flushed immediately.
- **UI:** one screen. Start/stop button, status (idle, connecting, listening, speaking, error), live transcript of both sides, and a passcode field on first use.
- **Provider selection:** configured by a single setting; default Gemini.

### 4.2 Voice adapter interface

The swap point. Every provider implements:

- `connect(config)` — open a session using a token and persona prompt.
- `sendAudio(chunk)` — send a mic audio chunk.
- `onAudio(cb)` — receive reply audio chunks.
- `onTranscript(cb)` — receive text for user and assistant turns.
- `onInterrupted(cb)` — provider signals the user barged in.
- `onError(cb)` / `onClose(cb)`.
- `close()`.

Stage 1 ships `GeminiLiveAdapter` plus a `FakeAdapter` used in tests. An `OpenAIRealtimeAdapter` is a later addition.

### 4.3 Token endpoint

- A small serverless function on a free host (Cloudflare Workers preferred).
- `POST /token` with a passcode. If the passcode matches a secret, returns a short-lived provider session token; otherwise 401.
- Secrets: provider API key and passcode, stored as host secrets, never committed.
- Basic rate limiting per IP to protect the free quota.

### 4.4 Persona prompt

Short, spoken-style answers. Reply in whichever language the user speaks (English or Danish). Warm household-assistant tone. Knows the home location (Solrød, Denmark). No tools in Stage 1, and it should say so plainly when asked for calendar, weather, or web information.

## 5. Data flow

1. User taps start; browser requests mic permission.
2. Client sends the passcode to `/token` and receives a short-lived token.
3. Client opens a live session with the provider and sends the persona prompt.
4. Mic audio streams up; reply audio and transcripts stream down.
5. On interruption, playback queue is flushed.
6. User taps stop, or the session times out; the client closes the session and releases the mic.

No audio or transcript is stored on the server. Transcripts live in memory in the page only.

## 6. Error handling

- **Mic denied:** show how to enable it; do not retry silently.
- **Token request fails (401/network):** show a clear message; prompt for the passcode again on 401.
- **Connection drop:** reconnect once automatically; if it fails, show a message and return to idle. Use the provider's session resumption if available (verify during build).
- **Session time limit:** end gracefully with a visible "session ended, tap to continue" state.
- **Free quota exhausted:** show "limit reached, try later" rather than silence.
- **Echo/feedback:** documented in the UI as "use headphones if it talks to itself".

## 7. Testing

- **Automated:** unit tests for the adapter interface using `FakeAdapter`; tests for the playback queue (flush on interruption); tests for the token endpoint (valid/invalid passcode, no key leakage in responses).
- **Manual checklist on a real phone**, recording latency each time:
  1. English conversation.
  2. Danish conversation.
  3. Mixed English/Danish in one conversation.
  4. Interrupting mid-reply.
  5. Long silence, then speaking.
  6. Background noise.
  7. Speaker (no headphones) vs headphones.
  8. Session resume or reconnect after a drop.
- **Pass bar:** the Stage 1 targets in section 2a. If the Danish targets are missed, trigger the fallback evaluation below.

## 8. Fallbacks and next stages

- **If Danish is poor on Gemini Live:** try the other free Live model; then evaluate the OpenAI adapter on a small prepaid balance with a hard cap.
- **Free fallback pipeline (optional):** browser built-in speech recognition and voice plus a free Gemini text model. Quality varies by phone, especially Danish voices.
- **Stage 2:** tools via the backend (calendar, weather, web search, household notes), exposed to the model in a provider-neutral format.
- **Stage 3:** wake word (on-device detector gating the mic), Android wrapper.
- **Stage 4:** home device with USB mic and speaker, running the same client and backend; move to a paid key for privacy.

## 9. Open items

- Confirm Danish support and quality in the Gemini Live models.
- Read actual free-tier rate limits in AI Studio.
- Pick the free host (Cloudflare Workers assumed) and passcode scheme.
- Decide the app name.
