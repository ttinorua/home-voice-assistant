# Stage 1 Voice Chat Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a phone web app for hands-free English/Danish voice chat on Gemini Live's free tier, behind a swappable voice-adapter interface and a passcode-protected token endpoint.

**Architecture:** A TypeScript browser client (mic capture, playback queue, session controller, one-screen UI) talks to Gemini Live through a `VoiceAdapter` interface. A Cloudflare Worker holds the Google API key and mints short-lived session tokens after a passcode check. All logic is built against a `FakeAdapter` first; only the Gemini adapter touches the real SDK.

**Tech Stack:** TypeScript, Vite, Vitest (jsdom for UI tests), `@google/genai`, Cloudflare Workers + Wrangler, plain Web Audio API (AudioWorklet). No UI framework.

**Spec:** `docs/superpowers/specs/2026-10-24-home-voice-assistant-design.md`

## Global Constraints

- Languages: English and Danish from the start; reply in the language the user speaks.
- Interaction: tap to start, then hands-free and interruptible. No wake word in Stage 1.
- Free tier only; cost 0. The provider API key exists only as a Worker secret, never in the browser, repo, or any response.
- Mic constraints: echo cancellation, noise suppression, and auto gain control all enabled.
- Reconnect automatically once on a dropped connection, then stop with a message.
- No audio or transcript stored on the server; transcripts live in page memory only.
- Provider is chosen by one config setting (default `gemini`); adding a provider must not change the UI or the token endpoint.
- No tools in Stage 1 (no calendar, weather, web search, memory).
- User-facing strings: `limit reached, try later`; `session ended, tap to continue`; `use headphones if it talks to itself`.
- Stage 1 targets (spec section 2a): median response delay at most 1.5 s; interruption stops audio within 0.5 s in 9 of 10 trials; Danish 8 of 10; mixed language 8 of 10; 10-minute run without restart; reconnect works in 4 of 5 forced drops.

## Review Focus

- Passcode that is empty, missing, very long (10 KB), or contains non-ASCII (`æøå`): the endpoint answers 401 or 400, never 500 and never a token. Pinned in Task 4.
- Tapping stop while still connecting: no session, mic stream, or socket is left open. Pinned in Task 7.
- A late audio chunk arriving after stop or after an interruption: must not play. Pinned in Tasks 3 and 7.
- Double-tapping start: exactly one session and one mic stream. Pinned in Task 7.
- Every exit path (stop, error, drop, timeout, mic denied) releases the mic. Pinned in Tasks 7 and 8.

## File Structure

```
package.json, tsconfig.json, vite.config.ts, index.html
public/capture-processor.js, manifest.webmanifest, sw.js
src/voice/adapter.ts         VoiceAdapter interface and shared types
src/voice/fakeAdapter.ts     test double implementing VoiceAdapter
src/voice/geminiLiveAdapter.ts
src/audio/pcm.ts             pure PCM conversion helpers
src/audio/playbackQueue.ts   gapless playback with flush
src/audio/micSource.ts       getUserMedia + AudioWorklet capture
src/config.ts, src/persona.ts, src/tokenClient.ts
src/session/sessionController.ts   state machine
src/ui/view.ts, src/main.ts
worker/src/index.ts, worker/wrangler.toml
tests/**                     mirrors src/ and worker/
docs/stage1-evaluation.md    manual test sheet and results
```

### Task 1: Scaffold, adapter interface, FakeAdapter

**Files:**
- Create: `package.json`, `tsconfig.json`, `vite.config.ts`, `src/voice/adapter.ts`, `src/voice/fakeAdapter.ts`
- Test: `tests/voice/fakeAdapter.test.ts`

**Interfaces:**
- Produces (`src/voice/adapter.ts`):
  - `type Role = 'user' | 'assistant'`
  - `interface TranscriptEvent { role: Role; text: string; final: boolean }`
  - `type VoiceErrorKind = 'quota' | 'network' | 'auth' | 'unknown'`
  - `interface VoiceError { kind: VoiceErrorKind; message: string }`
  - `type CloseReason = 'user' | 'timeout' | 'dropped'`
  - `interface VoiceConfig { token: string; persona: string; model: string }`
  - `interface VoiceAdapter { connect(c: VoiceConfig): Promise<void>; sendAudio(chunk: Int16Array): void; onAudio(cb: (chunk: Int16Array) => void): void; onTranscript(cb: (e: TranscriptEvent) => void): void; onInterrupted(cb: () => void): void; onError(cb: (e: VoiceError) => void): void; onClose(cb: (r: CloseReason) => void): void; close(): void }`
  - Audio contract: `sendAudio` takes 16 kHz mono PCM16; `onAudio` delivers 24 kHz mono PCM16.
- Produces (`src/voice/fakeAdapter.ts`): `class FakeAdapter implements VoiceAdapter` with test helpers `emitAudio(chunk)`, `emitTranscript(e)`, `emitInterrupted()`, `emitError(e)`, `emitClose(r)`, and inspectable fields `sent: Int16Array[]`, `connectCalls: VoiceConfig[]`, `closeCalls: number`, plus `failNextConnect(err: Error)`.

- [ ] **Step 1: Scaffold** the Vite + TypeScript + Vitest project (strict TS, `npm test` runs `vitest run`). Add `@google/genai` as a dependency.
- [ ] **Step 2: Write failing tests** in `tests/voice/fakeAdapter.test.ts`: `emitAudio delivers to the registered onAudio callback`; `sendAudio records chunks in sent`; `close increments closeCalls and fires onClose('user')`; `failNextConnect makes connect reject once, then succeed`.
- [ ] **Step 3: Run** `npx vitest run tests/voice/fakeAdapter.test.ts`. Expected: FAIL, modules missing.
- [ ] **Step 4: Implement** `adapter.ts` and `fakeAdapter.ts` exactly per the Interfaces block.
- [ ] **Step 5: Run** the same command. Expected: 4 passed.
- [ ] **Step 6: Commit** `feat: scaffold project, voice adapter interface, fake adapter`.

### Task 2: PCM helpers

**Files:**
- Create: `src/audio/pcm.ts`
- Test: `tests/audio/pcm.test.ts`

**Interfaces:**
- Produces: `floatToPcm16(input: Float32Array): Int16Array` (clamps to -1..1); `pcm16ToFloat(input: Int16Array): Float32Array`; `downsample(input: Float32Array, fromRate: number, toRate: number): Float32Array`; `pcm16ToBase64(input: Int16Array): string`; `base64ToPcm16(b64: string): Int16Array`. PCM is little-endian.

- [ ] **Step 1: Write failing tests**: `floatToPcm16 maps 1.0 to 32767 and -1.0 to -32768`; `floatToPcm16 clamps 2.5 to 32767`; `pcm16ToFloat round-trips within 1/32768`; `downsample 48000 to 16000 of 480 samples returns 160 samples`; `base64 round-trip returns identical Int16Array`; `base64ToPcm16 of an empty string returns an empty array`.
- [ ] **Step 2: Run** `npx vitest run tests/audio/pcm.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** the five functions in `src/audio/pcm.ts`. Downsample by averaging each input window (a simple box filter is enough for speech).
- [ ] **Step 4: Run** the same command. Expected: 6 passed.
- [ ] **Step 5: Commit** `feat: pcm conversion helpers`.

### Task 3: Playback queue with flush

**Files:**
- Create: `src/audio/playbackQueue.ts`
- Test: `tests/audio/playbackQueue.test.ts`

**Interfaces:**
- Consumes: `pcm16ToFloat` from Task 2.
- Produces: `interface AudioSink { now(): number; schedule(samples: Float32Array, startAt: number, sampleRate: number): { stop(): void } }` and `class PlaybackQueue { constructor(sink: AudioSink, sampleRate: number); enqueue(chunk: Int16Array): void; flush(): void; close(): void; isPlaying(): boolean }`. After `close()`, `enqueue` is a no-op.

- [ ] **Step 1: Write failing tests** with a fake `AudioSink`: `second chunk starts exactly when the first ends`; `flush stops every scheduled source`; `chunk enqueued after flush starts at sink.now(), not after the old tail`; `enqueue after close schedules nothing`; `isPlaying is false after the last chunk's end time passes`.
- [ ] **Step 2: Run** `npx vitest run tests/audio/playbackQueue.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `PlaybackQueue`, tracking a `nextStart` time and the list of live handles. Add a small `WebAudioSink` class in the same file wrapping `AudioContext` (not unit-tested; covered by Task 9).
- [ ] **Step 4: Run** the same command. Expected: 5 passed.
- [ ] **Step 5: Commit** `feat: playback queue with flush`.

### Task 4: Token endpoint (Cloudflare Worker)

**Files:**
- Create: `worker/src/index.ts`, `worker/wrangler.toml`
- Test: `tests/worker/token.test.ts`

**Interfaces:**
- Produces: `interface Env { GEMINI_API_KEY: string; PASSCODE: string; ALLOWED_ORIGIN: string }`; `interface TokenDeps { mint(): Promise<string>; now(): number }`; `handleRequest(req: Request, env: Env, deps: TokenDeps): Promise<Response>`; default export `{ fetch }` wiring real deps (`mint` calls the Google SDK auth-token API using `GEMINI_API_KEY`).
- Contract: `POST /token` with JSON `{ "passcode": string }`. Success: 200 `{ "token": string }`. Wrong, empty, missing, or oversize passcode: 401. Malformed JSON: 400. Wrong method or path: 404/405. More than 10 requests per minute per `CF-Connecting-IP`: 429. Origin not equal to `ALLOWED_ORIGIN`: 403. Passcode comparison is constant-time. CORS headers only for `ALLOWED_ORIGIN`.

- [ ] **Step 1: Write failing tests**: `valid passcode returns 200 and the minted token`; `wrong passcode returns 401 and does not call mint`; `empty body, missing field, and 10 KB passcode all return 401 or 400, never 500`; `passcode "æøå" wrong returns 401 without throwing`; `response body never contains GEMINI_API_KEY`; `11th request in a minute from one IP returns 429`; `foreign Origin returns 403`; `GET /token returns 405`.
- [ ] **Step 2: Run** `npx vitest run tests/worker/token.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `handleRequest` and the default export. Keep rate-limit state in a module-level `Map` (best-effort per isolate; note this in a code comment).
- [ ] **Step 4: Run** the same command. Expected: 8 passed.
- [ ] **Step 5: Verify provider facts.** Read Google's current Live API docs and record in a comment at the top of `worker/src/index.ts`: the SDK call that creates a short-lived token, its expiry options, and whether a token is single-use. Adjust `mint` to match. Run `npx vitest run tests/worker` again; expected: still 8 passed.
- [ ] **Step 6: Commit** `feat: passcode-protected token endpoint`.

### Task 5: Config, persona, token client

**Files:**
- Create: `src/config.ts`, `src/persona.ts`, `src/tokenClient.ts`
- Test: `tests/config.test.ts`, `tests/tokenClient.test.ts`

**Interfaces:**
- Produces: `config: { provider: 'gemini'; model: string; tokenUrl: string }` (values from Vite env with defaults; `model` is the Gemini Live model ID verified in Task 4 step 5); `PERSONA: string`; `class TokenError extends Error { status: number }`; `fetchToken(passcode: string, fetchImpl?: typeof fetch): Promise<string>`.

- [ ] **Step 1: Write failing tests**: `PERSONA mentions English, Danish and Solrød`; `PERSONA tells the assistant to answer briefly and to say plainly it cannot access calendar, weather or the web yet`; `config.provider defaults to gemini`; `fetchToken posts the passcode as JSON and returns the token`; `fetchToken throws TokenError with status 401 on a 401`; `fetchToken throws TokenError with status 0 on network failure`.
- [ ] **Step 2: Run** `npx vitest run tests/config.test.ts tests/tokenClient.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** the three files per the Interfaces block.
- [ ] **Step 4: Run** the same command. Expected: 6 passed.
- [ ] **Step 5: Commit** `feat: config, persona, token client`.

### Task 6: GeminiLiveAdapter

**Files:**
- Create: `src/voice/geminiLiveAdapter.ts`
- Test: `tests/voice/geminiLiveAdapter.test.ts`

**Interfaces:**
- Consumes: `VoiceAdapter` and types (Task 1); `pcm16ToBase64`, `base64ToPcm16` (Task 2).
- Produces: `class GeminiLiveAdapter implements VoiceAdapter` with constructor `(connectLive?: LiveConnect)`, where `LiveConnect` is a thin injectable wrapper over the SDK's live-connect call so tests can pass a mock session.

- [ ] **Step 1: Write failing tests** against a mock session: `connect passes token, model, persona, and enables input and output transcription`; `sendAudio sends base64 audio with mime type audio/pcm;rate=16000`; `server audio parts become onAudio chunks`; `interrupted flag fires onInterrupted`; `input/output transcription messages become TranscriptEvents with the right role`; `an error containing RESOURCE_EXHAUSTED or status 429 becomes kind quota`; `an unexpected socket close becomes onClose('dropped')`, and `close() becomes onClose('user')`.
- [ ] **Step 2: Run** `npx vitest run tests/voice/geminiLiveAdapter.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** the adapter. Before coding, check the current SDK message shapes and the audio sample rates against Google's docs; if they differ from the Task 1 audio contract (16 kHz in, 24 kHz out), update the contract and its tests in one commit. If the SDK offers session resumption, enable it in `connect` and pass the resume handle on the reconnect; record in a code comment whether it exists.
- [ ] **Step 4: Run** the same command. Expected: 8 passed.
- [ ] **Step 5: Commit** `feat: gemini live adapter`.

### Task 7: SessionController

**Files:**
- Create: `src/session/sessionController.ts`
- Test: `tests/session/sessionController.test.ts`

**Interfaces:**
- Consumes: `VoiceAdapter` (Task 1), `PlaybackQueue` (Task 3), `fetchToken`/`TokenError` (Task 5), `PERSONA`/`config` (Task 5).
- Produces: `type SessionState = 'idle' | 'connecting' | 'listening' | 'speaking' | 'error' | 'ended'`; `interface MicSource { start(onChunk: (c: Int16Array) => void): Promise<void>; stop(): void }` (a mic start failure rejects with `Error` whose `name` is `NotAllowedError` when permission is denied); `MESSAGES` (the three user-facing strings from Global Constraints plus a mic-denied message); `class SessionController { constructor(deps: { adapter: VoiceAdapter; mic: MicSource; playback: PlaybackQueue; getToken: (passcode: string) => Promise<string>; now: () => number }); start(passcode: string): Promise<void>; stop(): void; onState(cb: (s: SessionState) => void): void; onTranscript(cb: (e: TranscriptEvent) => void): void; onMessage(cb: (text: string, needsPasscode: boolean) => void): void; responseDelaysMs: number[] }`.
- Delay metric: time from the last user transcript update to the next assistant audio chunk; approximate, pushed to `responseDelaysMs`.

- [ ] **Step 1: Write failing tests** with `FakeAdapter`, a fake mic, and a fake sink:
  - `start goes idle → connecting → listening and streams mic chunks to sendAudio`
  - `first assistant audio sets state speaking; interrupted flushes the queue and returns to listening`
  - `stop releases the mic, closes the adapter, closes the queue, and ends in idle`
  - `stop during connecting leaves no open adapter and no running mic`
  - `calling start twice connects once and starts one mic`
  - `audio emitted after stop is not enqueued`
  - `token 401 gives state error, needsPasscode true`
  - `mic NotAllowedError gives the mic-denied message and does not retry`
  - `dropped close triggers exactly one reconnect; a second drop gives state error and releases the mic`
  - `quota error shows "limit reached, try later"`
  - `timeout close ends with "session ended, tap to continue"`
  - `responseDelaysMs records 400 when the clock moves 400 ms between last user transcript and first reply audio`
- [ ] **Step 2: Run** `npx vitest run tests/session/sessionController.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `SessionController` as a small state machine. Guard re-entrancy with the state; capture a `generation` counter so callbacks from a closed session are ignored.
- [ ] **Step 4: Run** the same command. Expected: 12 passed.
- [ ] **Step 5: Commit** `feat: session controller state machine`.

### Task 8: Mic capture, UI, PWA wiring

**Files:**
- Create: `src/audio/micSource.ts`, `public/capture-processor.js`, `src/ui/view.ts`, `src/main.ts`, `index.html`, `public/manifest.webmanifest`, `public/sw.js`
- Test: `tests/audio/micSource.test.ts`, `tests/ui/view.test.ts` (both `// @vitest-environment jsdom`)

**Interfaces:**
- Consumes: `MicSource`, `SessionController`, `MESSAGES` (Task 7); `downsample`, `floatToPcm16` (Task 2); `PlaybackQueue`/`WebAudioSink` (Task 3).
- Produces: `class BrowserMicSource implements MicSource`; `renderView(root: HTMLElement, model: { state: SessionState; transcript: TranscriptEvent[]; message?: string; showPasscode: boolean }, handlers: { onToggle(): void; onPasscode(v: string): void }): void`.

- [ ] **Step 1: Write failing tests**: `BrowserMicSource requests audio with echoCancellation, noiseSuppression and autoGainControl all true`; `stop stops every track of the stream`; `start rejects with NotAllowedError when getUserMedia is denied and leaves no tracks running`; `renderView shows "Start" when idle and "Stop" when listening or speaking`; `renderView shows the status text for each state`; `renderView shows the passcode field only when showPasscode is true`; `renderView shows the message text and the headphones hint in the error state`; `transcript entries render in order with the role as a label`.
- [ ] **Step 2: Run** `npx vitest run tests/audio/micSource.test.ts tests/ui/view.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `BrowserMicSource` (AudioWorklet in `capture-processor.js` posts Float32 blocks; the class downsamples to 16 kHz and converts to PCM16) and `renderView`.
- [ ] **Step 4: Wire `src/main.ts`**: build the real `GeminiLiveAdapter`, `BrowserMicSource`, `PlaybackQueue(new WebAudioSink(), 24000)` and `SessionController`; store the passcode in `localStorage` inside try/catch; register `sw.js` (app-shell cache only); add the manifest and an install icon.
- [ ] **Step 5: Run** `npx vitest run` and `npx vite build`. Expected: all tests pass; build succeeds.
- [ ] **Step 6: Commit** `feat: mic capture, one-screen UI, PWA shell`.

### Task 9: Deploy and run the Stage 1 evaluation

**Files:**
- Create: `docs/stage1-evaluation.md`

**Interfaces:**
- Consumes: everything above. Needs from the user: a Google AI Studio API key and a Cloudflare account.

- [ ] **Step 1: Deploy the Worker.** `npx wrangler secret put GEMINI_API_KEY`, then `PASSCODE`, then set `ALLOWED_ORIGIN` in `worker/wrangler.toml` to the front-end URL, then `npx wrangler deploy`. Verify: `curl -X POST <worker>/token -d '{"passcode":"wrong"}'` returns 401, and the correct passcode returns a token.
- [ ] **Step 2: Deploy the front end** to Cloudflare Pages (`npx vite build`, then publish `dist/`). Open it on the phone, add it to the home screen.
- [ ] **Step 3: Read the real free-tier limits** in AI Studio and record them at the top of `docs/stage1-evaluation.md`.
- [ ] **Step 4: Run the manual checklist** from the spec, section 7, on the phone. In `docs/stage1-evaluation.md`, record each of the 8 items with: result, `responseDelaysMs` median over 20 turns, interruption trials out of 10, Danish sentences out of 10, mixed-language turns out of 10, the 10-minute run, forced drops out of 5, self-echo runs, and your 1 to 5 daily-use rating.
- [ ] **Step 5: Decide.** Compare the results with the Stage 1 targets in spec section 2a and write one of: keep Gemini, add the OpenAI adapter, or change approach. Commit `docs: stage 1 evaluation results`.
