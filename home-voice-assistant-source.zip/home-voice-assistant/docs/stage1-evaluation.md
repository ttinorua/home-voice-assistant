# Stage 1 evaluation sheet

Fill this in on your phone after deploying (see `DEPLOY.md`). The targets come from section 2a of the design spec.

Free-tier limits seen in Google AI Studio (2026-10-24): Gemini 3.8 Live has no request-per-minute or per-day cap; tokens per minute 65K (our peak 1.61K). Concurrent-session and daily-minutes limits not shown.

## How to run each test

Use casual chat only (free-tier conversations may be used by Google). Do each test in a quiet room first, then once with background noise.

| # | Test | What to do | Target | Your result |
|---|---|---|---|---|
| 1 | English chat | Talk for 20 turns | Median reply delay at most 1.5 s | Median 1.3 s over 59 turns (meets target). Approximate, measured on screen. |
| 2 | Danish chat | 10 Danish sentences, e.g. ask about dinner ideas | At least 8 of 10 understood and answered in Danish | Not formally tested on the final version. Early test: switched to Danish fine. |
| 3 | Mixed language | 10 turns switching English and Danish | At least 8 of 10 answered in the language you used | Not tested on the final version. |
| 4 | Interrupting | Talk over the assistant 10 times | Stops within 0.5 s in at least 9 of 10 | Not formally counted. |
| 5 | Long silence | Stay quiet 60 seconds, then speak | Still works, no restart needed | Not formally tested. |
| 6 | Background noise | Run the TV or radio quietly | Still understands you | Not tested. |
| 7 | Speaker vs headphones | 5 runs on the phone speaker | No self-triggering, or write "headphones only" | Phone speaker runs worked without self-triggering. Bluetooth headset had range and patchy audio problems. |
| 8 | Drops | Switch Wi-Fi off and on during a chat, 5 times | At least 4 of 5 recover | Planned 10-minute reconnect worked every time (about 2 s). Wi-Fi off/on not tested. |
| 9 | Long run | Chat for 10 minutes | No manual restart | Pass: about 14 minutes, no restart, screen stayed on. |

## Things to watch for (tell me if you see any)

- The assistant's voice sounds too fast, too slow, or like a chipmunk. This would mean the audio speed setting needs fixing.
- It cannot hear you at all, or hears garbled words.
- The transcript on screen has words stuck together or missing spaces.

## Your verdict

Daily-use rating (1 to 5): not given   (target: at least 4)

Notes: Feels good with English-only, a female voice (Aoede) and the "stay quiet" switch. ChatGPT's own voice still feels more natural. The "adapt to tone" experiment is not supported by this model.

## Decision (fill in with me)

Decision (2026-10-24): keep Gemini free tier as the main voice for now. The OpenAI adapter is an optional later comparison.
